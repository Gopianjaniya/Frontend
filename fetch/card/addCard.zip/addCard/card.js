let addedCards = document.getElementById("added-cards");
let card = document.querySelector(".card");
let addBtn = card.querySelector(".addBtn");
let image = card.querySelector(".image img").src;
let price = card.querySelector(".price").innerText;
let desc = card.querySelector(".desc").innerText;
let cardData = { image, price, desc };
// localStorate save Data
localStorage.setItem("cardData", JSON.stringify(cardData));
// localStorate get Data
let getData = localStorage.getItem("cardData");
let Data = JSON.parse(getData);

try {
    addBtn.addEventListener("click", (event) => {
        let div = document.createElement("div");
        div.classList.add("cardJs");
        div.innerHTML = `<img src="${Data.image}" alt="photo" />

        <hr/>
        <div class="details">
        <span><b>${Data.price}</b></span>
        <p>${Data.desc}</p>
        <button class="remove">X</button></div>
       `;
        addedCards.append(div);

        let removeBtn = div.querySelector(".remove")

        removeBtn.addEventListener('click', (event) => {
            div.remove();
        })


    });
} catch (error) {
    console.log("error ", error);
}